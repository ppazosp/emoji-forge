# hello / bible

Compare the reference poses and palette. Note any identity or construction choices that need clarification.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Fixed seafoam outline, two leaves and short feet across the model and pose sheet.
