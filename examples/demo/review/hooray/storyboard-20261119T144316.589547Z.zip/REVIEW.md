# hooray / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The thumbnail animatic separates opening, action and return; hello uses one pose.
