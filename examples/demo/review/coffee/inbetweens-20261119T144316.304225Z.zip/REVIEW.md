# coffee / inbetweens

Inspect the cels, strips and timing. Call out off-model drawings, abrupt spacing or missing holds by frame.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The working cels step through the planned amounts. Reviewed at 32 and 128 px, with the full strip for edge checks.
