# coffee / final

Check the delivered scale, frame and byte limits, then inspect the overview and final strips at their intended size.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Export checks pass at 128 px. The overview includes the three animated files and one still.
