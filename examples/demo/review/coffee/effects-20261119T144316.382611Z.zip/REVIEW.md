# coffee / effects

Compare the clean and treated frames. Note timing, readability or clipping issues.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Only hooray uses the sparkle shader. Keep the flecks beside the face and within the padded canvas.
