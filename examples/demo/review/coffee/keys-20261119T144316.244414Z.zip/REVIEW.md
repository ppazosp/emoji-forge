# coffee / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The selected drawings make the gesture clear while retaining the same round face and lower body.
