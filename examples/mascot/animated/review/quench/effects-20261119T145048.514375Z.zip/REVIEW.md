# quench / effects

Compare the clean and treated frames. Note timing, readability or clipping issues.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Steam appears at the bucket in 03 and curls toward the tongs in 04. It stays clear of Ember's face.
