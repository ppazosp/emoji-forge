# quench / final

Check the delivered scale, frame and byte limits, then inspect the overview and final strips at their intended size.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

All 4 exposure(s) checked against light and dark at preview size and 128 px, with strip inspection for loose pixels. Slack export is 26,516 bytes at 128 × 128.
