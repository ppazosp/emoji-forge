# quench / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The bucket and feet share a baseline. The puck is distinct from the rim in 01 and at the waterline in 03.
