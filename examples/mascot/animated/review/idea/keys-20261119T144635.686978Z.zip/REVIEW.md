# idea / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

01 holds the thinking pose, 03 has a clear lifted hand, and the right edge has room for a glow.
