# idea / effects

Compare the clean and treated frames. Note timing, readability or clipping issues.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The bulb switches on at 03 and holds through the settle. Its dark keyline holds up on light.
