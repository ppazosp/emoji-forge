# idea / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The thoughtful hand at the apron leads to the raised mitten and space for a bulb.
