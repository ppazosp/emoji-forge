# idea / bible

Compare the reference poses and palette. Note any identity or construction choices that need clarification.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Front, three-quarter, side and rear keep the gold crown, blue goggle lenses and short apron. The expression sheet gives distinct rest, focus and pride references.
