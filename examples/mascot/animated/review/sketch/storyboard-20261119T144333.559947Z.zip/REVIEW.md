# sketch / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

A blank board grows a mark and then a recognisable face. Hold the reveal.
