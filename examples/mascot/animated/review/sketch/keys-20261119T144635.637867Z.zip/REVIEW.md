# sketch / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Board stays at right and pencil stays in the working mitten. The finished drawing reads clearly in 03.
