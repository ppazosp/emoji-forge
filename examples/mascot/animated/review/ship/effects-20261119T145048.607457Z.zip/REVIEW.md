# ship / effects

Compare the clean and treated frames. Note timing, readability or clipping issues.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The lid movement gives a clear accent at 03 without a separate effect.
