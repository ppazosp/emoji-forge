# ship / inbetweens

Inspect the cels, strips and timing. Call out off-model drawings, abrupt spacing or missing holds by frame.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

02 shows the disc crossing the rim and 04 gives the lid a small rebound. Feet and goggles stay stable. Reviewed all four cels against the model and neighbours. Whole-art drift flagged 4 style match(es) and no neighbour discontinuities.
