# ship / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

In 01 the disc is clearly above the opening. In 03 the lid is flat and the disc has disappeared.
