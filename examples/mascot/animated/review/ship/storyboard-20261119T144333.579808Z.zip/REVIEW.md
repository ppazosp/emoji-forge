# ship / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Open crate, drop and shut are easy to distinguish. The lid opens again as the cycle resets.
