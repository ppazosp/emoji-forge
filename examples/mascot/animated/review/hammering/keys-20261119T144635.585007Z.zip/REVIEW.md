# hammering / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Drawings 01 and 03 keep the anvil at right and put the hammer visibly against the blank on 03.
