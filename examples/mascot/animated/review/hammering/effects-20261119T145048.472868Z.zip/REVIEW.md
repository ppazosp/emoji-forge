# hammering / effects

Compare the clean and treated frames. Note timing, readability or clipping issues.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

03 puts the flash at the contact edge. A smaller streak remains as the hammer rebounds in 04.
