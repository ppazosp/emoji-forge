# wave / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

01 and 03 keep both eyes clear. The brown glove separates visually from the orange crown.
