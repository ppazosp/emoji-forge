# wave / inbetweens

Inspect the cels, strips and timing. Call out off-model drawings, abrupt spacing or missing holds by frame.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

02 reaches up and out, and 04 returns lower. The mitt, eyes and feet remain consistent. Reviewed all four cels against the model and neighbours. Whole-art drift flagged 0 style match(es) and no neighbour discontinuities.
