# wave / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Three outward/inward positions distinguish this loop from a static raised hand.
