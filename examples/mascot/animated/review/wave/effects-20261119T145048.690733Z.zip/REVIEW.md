# wave / effects

Compare the clean and treated frames. Note timing, readability or clipping issues.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

A clean silhouette and open smile carry the wave without a separate effect.
