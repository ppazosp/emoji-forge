# logo / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The still matches the reference goggles and flame, with a hammer tucked under one mitten.
