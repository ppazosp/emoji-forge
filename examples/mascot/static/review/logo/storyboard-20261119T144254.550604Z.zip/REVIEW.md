# logo / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

One centered thumbnail leaves the face, apron and hammer readable.
