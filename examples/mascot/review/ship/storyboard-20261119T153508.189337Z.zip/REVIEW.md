# ship / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The lid has a clear open, drop and close order.
