# ship / effects

Compare the clean and treated frames. Check that an impact flash or burst begins on contact and clears the character as it decays.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The lid and held pose supply the visual accent.
