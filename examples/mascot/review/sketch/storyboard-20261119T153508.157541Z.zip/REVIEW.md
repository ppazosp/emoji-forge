# sketch / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The blank sheet, partial mark and smiley reveal make the pencil action clear.
