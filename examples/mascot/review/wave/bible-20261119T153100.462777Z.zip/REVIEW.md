# wave / bible

Compare the reference poses and palette. Check the silhouette, palette and name for resemblance to recognizable existing characters.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The steel anvil, brass-and-teal goggles and graphite outline are visible at 32 px. Reviewed the name and silhouette.
