# wave / final

Check the delivered scale, frame and byte limits, then inspect the overview and final strips at their intended size.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Passed upload checks at 128 px. 6 frame(s), 29,756 bytes. Body drift 0.500%.
