# wave / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The moving hand reads outside the cheek at sticker size.
