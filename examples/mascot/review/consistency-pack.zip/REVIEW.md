# consistency

Read each lineup row across the whole pack. Check repeated features, relative prop size, silhouette, the scale report and the final motion on light and dark.

Return pass or fail, with notes and frame or panel references where useful.
