# quench / inbetweens

Inspect the cels, strips and timing. Call out off-model drawings, abrupt spacing, missed holds, and unintended scale or anchor changes by frame.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Intermediate drawings vary lowering and lifting without global scaling.
