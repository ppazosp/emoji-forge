# quench / effects

Compare the clean and treated frames. Check that an impact flash or burst begins on contact and clears the character as it decays.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Blue-white steam rises at the waterline and leaves Tavvik's face visible.
