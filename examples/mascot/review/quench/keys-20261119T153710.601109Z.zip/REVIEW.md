# quench / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Tongs close on the disc and its lower edge passes through the waterline.
