# quench / storyboard

Check whether the storyboard and timed thumbnail animatic communicate the idea.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Four storyboard beats clearly show lowering, dipping and lifting the disc.
