# hammering / final

Check the delivered scale, frame and byte limits, then inspect the overview and final strips at their intended size.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Reviewed all 30 frames at 512 px. One wrist and grip carry the perpendicular head through two flat strikes. The 128 px export passed the Slack preset and body drift was 0.167%.
