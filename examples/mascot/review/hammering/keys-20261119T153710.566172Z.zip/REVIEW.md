# hammering / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

Ready, high and flat contact keys retain the copper-banded hammer.
