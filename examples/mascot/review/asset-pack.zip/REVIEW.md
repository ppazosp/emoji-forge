# asset

Compare each asset's views and states against the bible. Check silhouette, palette, scale, construction and resemblance to existing designs.

Return pass or fail, with notes and frame or panel references where useful.
