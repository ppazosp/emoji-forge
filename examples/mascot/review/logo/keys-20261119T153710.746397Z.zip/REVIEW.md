# logo / keys

Compare the key drawings with the model, expression and pose sheets and the storyboard.

Return pass or fail, with notes and frame or panel references where useful.

Verdict: pass

The logo shares the same copper band, chamfers and short wrapped shaft as hammering.
