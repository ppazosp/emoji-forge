# integration

Check the fit, grip, contact and overlaps in the integration sheets and in the relevant motion exposures. Call out any apparent resizing or detached parts.

Return pass or fail, with notes and frame or panel references where useful.
